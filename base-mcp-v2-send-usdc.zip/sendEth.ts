import { parseEther } from "viem";
import { resolveBasename } from "./resolveBasename";

export interface SendEthResult {
  type: "SEND_ETH";
  success: boolean;
  message: string;
  value?: bigint;
  recipient?: `0x${string}`;
}

export async function sendEth(
  amount?: string,
  recipient?: string
): Promise<SendEthResult> {
  if (!amount) {
    return {
      type: "SEND_ETH",
      success: false,
      message: "Amount is required.",
    };
  }

  if (!recipient) {
    return {
      type: "SEND_ETH",
      success: false,
      message: "Recipient address is required.",
    };
  }

  let resolvedRecipient = recipient;

  if (
    recipient.endsWith(".base") ||
    recipient.endsWith(".base.eth")
  ) {
    const resolved = await resolveBasename(recipient);

    if (!resolved.success || !resolved.address) {
      return {
        type: "SEND_ETH",
        success: false,
        message: resolved.message,
      };
    }

    resolvedRecipient = resolved.address;
  }

  try {
    const value = parseEther(amount);

    return {
      type: "SEND_ETH",
      success: true,
      message: `Sending ${amount} ETH to ${recipient}`,
      value,
      recipient: resolvedRecipient as `0x${string}`,
    };
  } catch {
    return {
      type: "SEND_ETH",
      success: false,
      message: "Invalid ETH amount.",
    };
  }
}